// API KEY : M9FSZRENPPBEPA2PU7CTUBVB5
// I just create this wheather site using tailwind css and js using weather api from weather.visualcrossing.com

const fd = async () => {
  document.getElementById("space").innerHTML = "Fetching Data";
  try {
    const city = document.getElementById("inp").value;
    const x = await fetch(
      `https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${city}?unitGroup=us&key=M9FSZRENPPBEPA2PU7CTUBVB5`
    );
    let d = await x.json();

    // inners...
    const td = d.currentConditions.datetime;
    let str = td;
    let num = parseInt(str);
    // image condition

    if (num > 6) {
      document.getElementById("s").src = "./images/monnclouds.png";
      document.getElementById("space").innerHTML = td + "    Night...🌉";
    }
    if (num < 18) {
      document.getElementById("s").src = "./images/realsun.png";
      document.getElementById("space").innerHTML = td + "    Day...🌄";
    }

    document.getElementById("floww").innerHTML = d.timezone;
    document.getElementById("con").innerHTML = d.currentConditions.conditions;
    document.getElementById("icon").innerHTML = d.currentConditions.icon;
    document.getElementById("tempa").innerHTML = d.currentConditions.temp + "C";
    document.getElementById("desc").innerHTML = d.description;
    document.getElementById("tempp").innerHTML = d.currentConditions.temp + "C";

    document.getElementById("humidity").innerHTML =
      d.currentConditions.humidity + "%";
    document.getElementById("wind").innerHTML =
      d.currentConditions.dew + "km / h";

    document.getElementById("ss2").src = "./images/sunrain.png";
    document.getElementById("ss3").src = "./images/fullrain.png";
    document.getElementById("ss4").src = "./images/monnclouds.png";

    // Boxes
    // 1
    document.getElementById("boxt0").innerHTML = "NOW";
    document.getElementById("boxc0").innerHTML = d.currentConditions.temp + "C";

    // 1
    document.getElementById("boxc1").innerHTML =
      d.days[0].hours[0].temp + " C ";
    document.getElementById("boxt1").innerHTML = d.days[0].hours[0].datetime;

    // 1
    document.getElementById("boxc2").innerHTML =
      d.days[0].hours[15].temp + " C ";
    document.getElementById("boxt2").innerHTML = d.days[0].hours[15].datetime;

    // 1
    document.getElementById("boxc3").innerHTML =
      d.days[0].hours[20].temp + " C ";
    document.getElementById("boxt3").innerHTML = d.days[0].hours[20].datetime;

    // 1
    document.getElementById("boxc4").innerHTML =
      d.days[0].hours[23].temp + " C ";
    document.getElementById("boxt4").innerHTML = d.days[0].hours[23].datetime;
  } catch (er) {
    document.getElementById("space").innerHTML =
      "Data Not Fetch Please Enter Valid Country..";
  }
};
